# bello-hacked-2025

## Team Members
- Grace Shin
- Sarang Kim
- Taehun Lee
- Marcus Kim
- Karina Zhang
